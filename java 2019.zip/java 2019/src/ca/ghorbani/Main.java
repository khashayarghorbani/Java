package ca.ghorbani;

import java.util.Scanner;

public class Main {
    //Global static variables are automatically initialized with value
    // 0 or false



    private static void numbers1To100() {
        int n = 1;
        int sum = 0;
        for (int k = n; k <= 100; k += 1) {
            sum += k;
        }
        System.out.println("the value is : " + sum);

    }

    private static void multipleOf3And5Below1000() {
        int summ = 0;
        for (int k = 0; k < 1000; k++) {
            if (k % 3 == 0 || k % 5 == 0) {
                summ += k;
            }


        }


        System.out.println("The value is : " + summ);
    }

    public static void main(String[] args) {
        Salary("khashayar",50_000,25 );
        System.out.println("\n");

        // Variables.variables();
        //Conditions.condition();
        Factorial.fac();
        Loop.loop();
        Variables.variables();

        Scanner sn = new Scanner(System.in);

        System.out.println("Hello. Whats your email address?");
        String email = sn.next();
        System.out.println("your email adress is ");
        for (int k = email.length() - 1; k >= 0; k -= 1) {
            System.out.print(email.charAt(k));
        }
        System.out.println("\n\n");


        boolean exit = false;
        do {

            System.out.println("select one");
            System.out.println("1- add numbers from 1 to 100");
            System.out.println("2- multiples of 3 and 5 below 1000");
            System.out.println("3- option C");
            System.out.println("4- option D");
            System.out.println("5- multiply parameters");
            System.out.println("6- prime");
            System.out.println("7- first 100 number is prime");
            int userChoice = sn.nextInt();
            switch (userChoice) {
                case 1:
                case 0:
                    numbers1To100();
                    break;
                case 2:

                    multipleOf3And5Below1000();

                    break;
                case 3:
                    int num1, num2;
                    System.out.println("number 1? : ");
                    num1 = sn.nextInt();
                    System.out.println("number 2? : ");
                    num2 = sn.nextInt();

                    System.out.println(num1 + " + " + num2 + " = " + add(num1, num2));
                    break;
                case 4:
                    int number1, number2, num3;
                    System.out.println("number 1? : ");
                    number1 = sn.nextInt();
                    System.out.println("number 2? : ");
                    number2 = sn.nextInt();
                    System.out.println("number 3? : ");
                    num3 = sn.nextInt();

                    System.out.println(number1 + " + " + number2 + " + " + num3 + " = " + add(number1, number2, num3));
                    break;
                case 5:
                    System.out.println(multiply(2, 5, 10));
                case 6:
                    System.out.println("which number? ");
                    int number = sn.nextInt();
                    System.out.println(isPrime((number)));
                    break;


                case 7:
                    for (int k = 1; k < 100; k++) {
                        System.out.println(k + " is prime ? " + isPrime(k));

                    }
                    break;

                default:
                    exit = true;
                    System.out.println("bye");
                    break;

            }

        } while (!exit);
        // functions
    }

    //methods must have a return type
    private static int add(int number1, int number2) {
        return number1 + number2;
    }

    //overloading
    private static int add(int number1, int number2, int number3) {
        return number1 + number2 + number3;
    }
    private static void Salary(String name, double salary, double workingHour) {
        System.out.println("hello " + name);
        System.out.format("you are making %.1f CAD/hour " , salary/52/workingHour);
    }




    //inlimited parameters
    private static int multiply(int... nums) {
        int result = 1;
        for (int i = 0; i < nums.length; i++) {
            result *= 1;

        }
        return result;
    }


    private static boolean isPrime(int number) {
        if (number < 2) {
            return false;

        }
        if (number == 2) {
            return true;
        }

        for (int i = 2; i < (int) Math.sqrt(number) + 1; i += 1) {
            if (number % i == 0) {
                return false;

            }
        }
        return true;
    }
}
