package ca.ghorbani;

public class Loop {
    static void loop(){
        System.out.println("test from loop method");
        //2 conditional loop
        // first one is counter loop - for
        // second one is conditional loop - while
        System.out.println("________");
        System.out.println("printing from 1 - 10 number");
        for (int i = 0; i < 10; i +=1){
            int Print = i + 1;
            System.out.println(Print);
        }

        System.out.println("________");
        System.out.println("printing the power of 2 starting from 10 to 0");
        for (int i = 10; i > 0 ; i-= 1) {
            System.out.println("2 ^ " + i + " = " + Math.pow(2,i));

        }
        for (char i ='A' ; i <= 'Z' ; i+=1) {
            System.out.println(i + " ");

        }

        //counter loop is for
        for (int i = 0; i < 10; i += 1) {
            System.out.println("do this 10 time");

        }
        // condition loop is while
        int j = 0;
        while (j < 10) {
            System.out.println("continue as long as j is less than 10");
            j += 1;
        }
        //do while
        j = 0;
        do {
            System.out.println("do while loop");
            j += 1;
        } while (j < 10);

        int i = 0;
        while (i < 10) {
            if (i == 5) {
                i += 1;
                continue;

            }
            System.out.println("i value is " + i);
            i += 1;
        }
        /*
            odd numbers (if  i % 2 == 1 it would be even numbers)
            int i = 0;
        while(i < 10){
            if (i % 2 == 0){
                i += 1;
                continue;

            }
            System.out.println("i value is " + i);
            i += 1;


         */
       /* int age;
        Scanner sn = new Scanner(System.in);
        System.out.println("how old are you?");
        age = sn.nextInt();
        System.out.println("you are " + age + " years old");
        System.out.println("whats your name?");
        String name;
        name = sn.next();
        System.out.println("hi " + name + " nice to meet you!");
        System.out.println("you are " + age + " years old.");

        String password;
        System.out.println("whats your password?");
        password = sn.next();
        System.out.println("your password is ");
        for (int k = 0; k < password.length() ; k += 1) {
            System.out.print("*");

        }




        */


    }
}
