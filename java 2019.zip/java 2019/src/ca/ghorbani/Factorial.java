package ca.ghorbani;

public class Factorial {
    static void fac(){
        for (int i = 1; i<10; i+=1){
            System.out.println("factorial "+ i + "=" + factorial(i));
        }
        System.out.println("\n");
        for (int i = 0; i<10; i+=1){
            System.out.println("fibonacci "+ i + "=" + fibonacci(i));
        }
        System.out.println("\n");
        System.out.println("The area of circle is = " + area(5));
        System.out.println("\n");
        System.out.println("The area of rectangle is = " + area(2,-1));
    }


    static int factorial (int number){
       /* if (number<1){
            return -1;
        }
        if (number == 1){
            return 1;
        }
        return number * factorial(number-1);

        */
        return (number < 1) ? -1 : (number == 1) ? 1 : number *factorial(number-1);

    }
    static long fibonacci (int number){
        if ( number < 1 ) return -1;
        if ( number == 1 ) return 0;
        if ( number == 2 ) return 1;
        return fibonacci(number-2) + fibonacci(number-1);
        // return (number < 1) ? -1 : number == 1
        //                     ? 0 : number == 2
        //                     ? 1 : fibonacci( number -2) + fibonacci (number -1);
    }
     int number = 100;
    static void increment (int number){
        number +=1;
        System.out.println("increment number is " + number);
    }
    static long area(double radius){
        if(radius < 1) return -1;
        return (long)(Math.pow(radius,2)* Math.PI);


    }

    static double area(double x ,double y){
        if (x < 1 || y <1) return -1;
        return  x * y;
    }

    static void Fee(double fee, int payment){


        if (payment == 1){
            //calculation based on month
            System.out.println("you need to pay " + fee/12 + " every month");
        }
        if (payment == 2){
            //calculation based on quarter
            System.out.println("you need to pay " + fee/4 + " every month");

        }
    }




}
